﻿namespace WindowsFormsApp1
{
    partial class MapaMemoria
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_regA = new System.Windows.Forms.TextBox();
            this.tb_regL = new System.Windows.Forms.TextBox();
            this.tb_regCP = new System.Windows.Forms.TextBox();
            this.tb_regX = new System.Windows.Forms.TextBox();
            this.tb_regSW = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tb_tam = new System.Windows.Forms.TextBox();
            this.tb_inicio = new System.Windows.Forms.TextBox();
            this.boton_abrir = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.tb_nombrep = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.dg_mapamemoria = new System.Windows.Forms.DataGridView();
            this.cn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c0 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.c9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ca = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cb = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cc = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ce = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label9 = new System.Windows.Forms.Label();
            this.numericUpDownInstrucciones = new System.Windows.Forms.NumericUpDown();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.tb_CC = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.buttonEjecutar = new System.Windows.Forms.Button();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStrip();
            this.listViewEjecucion = new System.Windows.Forms.ListView();
            this.numLinea = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.direccion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.etiqueta = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.instruccion = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.valor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.cO = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.button1 = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dg_mapamemoria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownInstrucciones)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(440, 35);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Registro A";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(649, 12);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Registro L";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(434, 12);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Registro CP";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(639, 35);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Registro SW";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(440, 58);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 13);
            this.label5.TabIndex = 6;
            this.label5.Text = "Registro X";
            // 
            // tb_regA
            // 
            this.tb_regA.Location = new System.Drawing.Point(500, 32);
            this.tb_regA.Margin = new System.Windows.Forms.Padding(2);
            this.tb_regA.Name = "tb_regA";
            this.tb_regA.ReadOnly = true;
            this.tb_regA.Size = new System.Drawing.Size(127, 20);
            this.tb_regA.TabIndex = 8;
            this.tb_regA.Text = "FFFFFF";
            // 
            // tb_regL
            // 
            this.tb_regL.Location = new System.Drawing.Point(709, 10);
            this.tb_regL.Margin = new System.Windows.Forms.Padding(2);
            this.tb_regL.Name = "tb_regL";
            this.tb_regL.ReadOnly = true;
            this.tb_regL.Size = new System.Drawing.Size(127, 20);
            this.tb_regL.TabIndex = 9;
            this.tb_regL.Text = "FFFFFF";
            // 
            // tb_regCP
            // 
            this.tb_regCP.Location = new System.Drawing.Point(500, 10);
            this.tb_regCP.Margin = new System.Windows.Forms.Padding(2);
            this.tb_regCP.Name = "tb_regCP";
            this.tb_regCP.ReadOnly = true;
            this.tb_regCP.Size = new System.Drawing.Size(127, 20);
            this.tb_regCP.TabIndex = 11;
            this.tb_regCP.Text = "FFFFFF";
            // 
            // tb_regX
            // 
            this.tb_regX.Location = new System.Drawing.Point(500, 55);
            this.tb_regX.Margin = new System.Windows.Forms.Padding(2);
            this.tb_regX.Name = "tb_regX";
            this.tb_regX.ReadOnly = true;
            this.tb_regX.Size = new System.Drawing.Size(127, 20);
            this.tb_regX.TabIndex = 10;
            this.tb_regX.Text = "FFFFFF";
            // 
            // tb_regSW
            // 
            this.tb_regSW.Location = new System.Drawing.Point(709, 32);
            this.tb_regSW.Margin = new System.Windows.Forms.Padding(2);
            this.tb_regSW.Name = "tb_regSW";
            this.tb_regSW.ReadOnly = true;
            this.tb_regSW.Size = new System.Drawing.Size(127, 20);
            this.tb_regSW.TabIndex = 12;
            this.tb_regSW.Text = "FFFFFF";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(183, 35);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(57, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Inicio Prog";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(194, 58);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(46, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "Tamaño";
            // 
            // tb_tam
            // 
            this.tb_tam.Location = new System.Drawing.Point(243, 55);
            this.tb_tam.Margin = new System.Windows.Forms.Padding(2);
            this.tb_tam.Name = "tb_tam";
            this.tb_tam.ReadOnly = true;
            this.tb_tam.Size = new System.Drawing.Size(127, 20);
            this.tb_tam.TabIndex = 16;
            // 
            // tb_inicio
            // 
            this.tb_inicio.Location = new System.Drawing.Point(243, 32);
            this.tb_inicio.Margin = new System.Windows.Forms.Padding(2);
            this.tb_inicio.Name = "tb_inicio";
            this.tb_inicio.ReadOnly = true;
            this.tb_inicio.Size = new System.Drawing.Size(127, 20);
            this.tb_inicio.TabIndex = 15;
            // 
            // boton_abrir
            // 
            this.boton_abrir.Location = new System.Drawing.Point(9, 8);
            this.boton_abrir.Margin = new System.Windows.Forms.Padding(2);
            this.boton_abrir.Name = "boton_abrir";
            this.boton_abrir.Size = new System.Drawing.Size(92, 21);
            this.boton_abrir.TabIndex = 17;
            this.boton_abrir.Text = "Archivo OBJ";
            this.boton_abrir.UseVisualStyleBackColor = true;
            this.boton_abrir.Click += new System.EventHandler(this.boton_abrir_Click_1);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(131, 12);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(106, 13);
            this.label8.TabIndex = 18;
            this.label8.Text = "Nombre de programa";
            // 
            // tb_nombrep
            // 
            this.tb_nombrep.Location = new System.Drawing.Point(243, 10);
            this.tb_nombrep.Margin = new System.Windows.Forms.Padding(2);
            this.tb_nombrep.Name = "tb_nombrep";
            this.tb_nombrep.ReadOnly = true;
            this.tb_nombrep.Size = new System.Drawing.Size(127, 20);
            this.tb_nombrep.TabIndex = 19;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.dg_mapamemoria);
            this.panel1.Location = new System.Drawing.Point(9, 98);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(945, 296);
            this.panel1.TabIndex = 20;
            // 
            // dg_mapamemoria
            // 
            this.dg_mapamemoria.AllowUserToOrderColumns = true;
            this.dg_mapamemoria.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dg_mapamemoria.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dg_mapamemoria.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cn,
            this.c0,
            this.c1,
            this.c2,
            this.c3,
            this.c4,
            this.c5,
            this.c6,
            this.c7,
            this.c8,
            this.c9,
            this.ca,
            this.cb,
            this.cc,
            this.cd,
            this.ce,
            this.cf});
            this.dg_mapamemoria.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dg_mapamemoria.Location = new System.Drawing.Point(0, 0);
            this.dg_mapamemoria.Margin = new System.Windows.Forms.Padding(2);
            this.dg_mapamemoria.Name = "dg_mapamemoria";
            this.dg_mapamemoria.RowTemplate.Height = 24;
            this.dg_mapamemoria.Size = new System.Drawing.Size(945, 296);
            this.dg_mapamemoria.TabIndex = 2;
            // 
            // cn
            // 
            this.cn.HeaderText = "";
            this.cn.Name = "cn";
            // 
            // c0
            // 
            this.c0.HeaderText = "0";
            this.c0.Name = "c0";
            // 
            // c1
            // 
            this.c1.HeaderText = "1";
            this.c1.Name = "c1";
            // 
            // c2
            // 
            this.c2.HeaderText = "2";
            this.c2.Name = "c2";
            // 
            // c3
            // 
            this.c3.HeaderText = "3";
            this.c3.Name = "c3";
            // 
            // c4
            // 
            this.c4.HeaderText = "4";
            this.c4.Name = "c4";
            // 
            // c5
            // 
            this.c5.HeaderText = "5";
            this.c5.Name = "c5";
            // 
            // c6
            // 
            this.c6.HeaderText = "6";
            this.c6.Name = "c6";
            // 
            // c7
            // 
            this.c7.HeaderText = "7";
            this.c7.Name = "c7";
            // 
            // c8
            // 
            this.c8.HeaderText = "8";
            this.c8.Name = "c8";
            // 
            // c9
            // 
            this.c9.HeaderText = "9";
            this.c9.Name = "c9";
            // 
            // ca
            // 
            this.ca.HeaderText = "A";
            this.ca.Name = "ca";
            // 
            // cb
            // 
            this.cb.HeaderText = "B";
            this.cb.Name = "cb";
            // 
            // cc
            // 
            this.cc.HeaderText = "C";
            this.cc.Name = "cc";
            // 
            // cd
            // 
            this.cd.HeaderText = "D";
            this.cd.Name = "cd";
            // 
            // ce
            // 
            this.ce.HeaderText = "E";
            this.ce.Name = "ce";
            // 
            // cf
            // 
            this.cf.HeaderText = "F";
            this.cf.Name = "cf";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(805, 457);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 13);
            this.label9.TabIndex = 23;
            this.label9.Text = "Instrucciones: ";
            this.label9.Visible = false;
            // 
            // numericUpDownInstrucciones
            // 
            this.numericUpDownInstrucciones.Location = new System.Drawing.Point(907, 450);
            this.numericUpDownInstrucciones.Margin = new System.Windows.Forms.Padding(2);
            this.numericUpDownInstrucciones.Name = "numericUpDownInstrucciones";
            this.numericUpDownInstrucciones.Size = new System.Drawing.Size(45, 20);
            this.numericUpDownInstrucciones.TabIndex = 24;
            this.numericUpDownInstrucciones.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(11, 413);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(51, 18);
            this.label10.TabIndex = 26;
            this.label10.Text = "Efecto";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(6, 76);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(45, 18);
            this.label11.TabIndex = 27;
            this.label11.Text = "Mapa";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(244, 445);
            this.button2.Margin = new System.Windows.Forms.Padding(2);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(82, 26);
            this.button2.TabIndex = 29;
            this.button2.Text = "Limpiar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tb_CC
            // 
            this.tb_CC.Location = new System.Drawing.Point(709, 55);
            this.tb_CC.Margin = new System.Windows.Forms.Padding(2);
            this.tb_CC.Name = "tb_CC";
            this.tb_CC.ReadOnly = true;
            this.tb_CC.Size = new System.Drawing.Size(127, 20);
            this.tb_CC.TabIndex = 31;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(684, 58);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(21, 13);
            this.label12.TabIndex = 30;
            this.label12.Text = "CC";
            // 
            // buttonEjecutar
            // 
            this.buttonEjecutar.Location = new System.Drawing.Point(118, 445);
            this.buttonEjecutar.Margin = new System.Windows.Forms.Padding(2);
            this.buttonEjecutar.Name = "buttonEjecutar";
            this.buttonEjecutar.Size = new System.Drawing.Size(122, 26);
            this.buttonEjecutar.TabIndex = 32;
            this.buttonEjecutar.Text = "Ejecutar (Todo)";
            this.buttonEjecutar.UseVisualStyleBackColor = true;
            this.buttonEjecutar.Click += new System.EventHandler(this.buttonEjecutar_Click_1);
            //this.buttonEjecutar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.buttonEjecutar_KeyPress);
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStripStatusLabel1.Location = new System.Drawing.Point(0, 0);
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(963, 20);
            this.toolStripStatusLabel1.TabIndex = 33;
            this.toolStripStatusLabel1.Text = "toolStrip1";
            this.toolStripStatusLabel1.Visible = false;
            // 
            // listViewEjecucion
            // 
            this.listViewEjecucion.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.listViewEjecucion.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.numLinea,
            this.direccion,
            this.etiqueta,
            this.instruccion,
            this.valor,
            this.cO});
            this.listViewEjecucion.GridLines = true;
            this.listViewEjecucion.Location = new System.Drawing.Point(10, 477);
            this.listViewEjecucion.Name = "listViewEjecucion";
            this.listViewEjecucion.Size = new System.Drawing.Size(944, 132);
            this.listViewEjecucion.TabIndex = 39;
            this.listViewEjecucion.UseCompatibleStateImageBehavior = false;
            this.listViewEjecucion.View = System.Windows.Forms.View.Details;
            // 
            // numLinea
            // 
            this.numLinea.Text = "CP";
            this.numLinea.Width = 90;
            // 
            // direccion
            // 
            this.direccion.Text = "Instrucción";
            this.direccion.Width = 114;
            // 
            // etiqueta
            // 
            this.etiqueta.Text = "Cod. Op";
            this.etiqueta.Width = 165;
            // 
            // instruccion
            // 
            this.instruccion.Text = "Mod. Direcc";
            this.instruccion.Width = 161;
            // 
            // valor
            // 
            this.valor.Text = "Operando";
            this.valor.Width = 169;
            // 
            // cO
            // 
            this.cO.Text = "Efecto";
            this.cO.Width = 552;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(10, 445);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(103, 26);
            this.button1.TabIndex = 40;
            this.button1.Text = "Ejecutar (1 en 1)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // MapaMemoria
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(963, 610);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.listViewEjecucion);
            this.Controls.Add(this.buttonEjecutar);
            this.Controls.Add(this.tb_CC);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.numericUpDownInstrucciones);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tb_nombrep);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.boton_abrir);
            this.Controls.Add(this.tb_tam);
            this.Controls.Add(this.tb_inicio);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.tb_regSW);
            this.Controls.Add(this.tb_regCP);
            this.Controls.Add(this.tb_regX);
            this.Controls.Add(this.tb_regL);
            this.Controls.Add(this.tb_regA);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.toolStripStatusLabel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.MaximizeBox = false;
            this.Name = "MapaMemoria";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.MapaMemoria_KeyDown);
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dg_mapamemoria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownInstrucciones)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_regA;
        private System.Windows.Forms.TextBox tb_regL;
        private System.Windows.Forms.TextBox tb_regCP;
        private System.Windows.Forms.TextBox tb_regX;
        private System.Windows.Forms.TextBox tb_regSW;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_tam;
        private System.Windows.Forms.TextBox tb_inicio;
        private System.Windows.Forms.Button boton_abrir;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox tb_nombrep;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numericUpDownInstrucciones;
        private System.Windows.Forms.Button b_ejecutar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox tb_CC;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button buttonEjecutar;
        private System.Windows.Forms.ToolStrip toolStripStatusLabel1;
        private System.Windows.Forms.DataGridView dg_mapamemoria;
        private System.Windows.Forms.DataGridViewTextBoxColumn cn;
        private System.Windows.Forms.DataGridViewTextBoxColumn c0;
        private System.Windows.Forms.DataGridViewTextBoxColumn c1;
        private System.Windows.Forms.DataGridViewTextBoxColumn c2;
        private System.Windows.Forms.DataGridViewTextBoxColumn c3;
        private System.Windows.Forms.DataGridViewTextBoxColumn c4;
        private System.Windows.Forms.DataGridViewTextBoxColumn c5;
        private System.Windows.Forms.DataGridViewTextBoxColumn c6;
        private System.Windows.Forms.DataGridViewTextBoxColumn c7;
        private System.Windows.Forms.DataGridViewTextBoxColumn c8;
        private System.Windows.Forms.DataGridViewTextBoxColumn c9;
        private System.Windows.Forms.DataGridViewTextBoxColumn ca;
        private System.Windows.Forms.DataGridViewTextBoxColumn cb;
        private System.Windows.Forms.DataGridViewTextBoxColumn cc;
        private System.Windows.Forms.DataGridViewTextBoxColumn cd;
        private System.Windows.Forms.DataGridViewTextBoxColumn ce;
        private System.Windows.Forms.DataGridViewTextBoxColumn cf;
        private System.Windows.Forms.ListView listViewEjecucion;
        private System.Windows.Forms.ColumnHeader numLinea;
        private System.Windows.Forms.ColumnHeader direccion;
        private System.Windows.Forms.ColumnHeader etiqueta;
        private System.Windows.Forms.ColumnHeader instruccion;
        private System.Windows.Forms.ColumnHeader valor;
        private System.Windows.Forms.ColumnHeader cO;
        private System.Windows.Forms.Button button1;
    }
}